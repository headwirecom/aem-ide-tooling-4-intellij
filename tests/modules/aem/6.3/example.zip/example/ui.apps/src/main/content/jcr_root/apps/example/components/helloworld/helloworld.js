"use strict";

use(function () {

    var compObj = {};

    // Add your code here.
    compObj.text = granite.resource.properties['text'];

    return compObj;
});
