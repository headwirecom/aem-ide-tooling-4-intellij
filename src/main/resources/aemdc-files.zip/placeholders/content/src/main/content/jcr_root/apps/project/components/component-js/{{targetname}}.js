"use strict";

use(function () {

    var compObj = {};

    // Add your code here.
    compObj.text = "No text saved";

    return compObj;
});
