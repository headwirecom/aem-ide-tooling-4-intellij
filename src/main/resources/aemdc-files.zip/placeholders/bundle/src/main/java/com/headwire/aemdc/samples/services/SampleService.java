package {{ java-package }};

public interface {{ java-class }} {

  String getPropValue();
}
